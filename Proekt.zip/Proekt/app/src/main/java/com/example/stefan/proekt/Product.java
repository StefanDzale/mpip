package com.example.stefan.proekt;

/**
 * Created by Stefan on 13.1.2018.
 */

public class Product {

public String title;
public int price;

public Product(String title, int price){
    this.title=title;
    this.price=price;
}

}
