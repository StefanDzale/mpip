package com.example.stefan.proekt;

import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class ProductInfo extends RecyclerView.ViewHolder {

    public ImageView icon;
    public TextView title;
    public TextView price;
    public Button button;

    public ProductInfo(View itemView) {
        super(itemView);
    }
}
