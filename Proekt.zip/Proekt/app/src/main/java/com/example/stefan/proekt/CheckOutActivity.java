package com.example.stefan.proekt;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class CheckOutActivity extends AppCompatActivity {


    int price;

    private RecyclerView recyclerView;
    private ArrayList<String> cart=new ArrayList<>();
    CheckOutAdapter adapter;
    private List<Product> productsList=new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_check_out);

        recyclerView=(RecyclerView)findViewById(R.id.checkOutView);
        LinearLayoutManager layoutManager=new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        adapter=new CheckOutAdapter(this);

        price=getIntent().getExtras().getInt("total");
        String total=Integer.toString(price);

        TextView textView=(TextView)findViewById(R.id.totalPrice);
        textView.setText("Total Price: " + total);

        cart= getIntent().getStringArrayListExtra("cartList");

        adapter.setData(cart);
        recyclerView.setAdapter(adapter);

    }
}
