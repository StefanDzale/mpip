package com.example.stefan.proekt;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private List<Product> productsList=new ArrayList<>();
    ProductAdapter adapter;
    private Context mContext;

    private ArrayList<String> inCart=new ArrayList<>();
    private int totalPrice=0;

    private BroadcastReceiver mRandomNumberReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            Toast.makeText(MainActivity.this, "Added To Cart", Toast.LENGTH_LONG).show();
            inCart.add(intent.getExtras().getString("title"));
            totalPrice+=intent.getExtras().getInt("price");
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView=(RecyclerView)findViewById(R.id.products);
        LinearLayoutManager layoutManager=new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        adapter=new ProductAdapter(this);

        productsList.add(new Product("Product 1",20));
        productsList.add(new Product("Product 2",30));
        productsList.add(new Product("Product 3",40));
        adapter.setData(productsList);
        recyclerView.setAdapter(adapter);

        mContext = getApplicationContext();

        LocalBroadcastManager.getInstance(mContext).registerReceiver(
                mRandomNumberReceiver,
                new IntentFilter("BROADCAST_RANDOM_NUMBER")
        );
    }

    public void sendCart(View view){
        Intent sendIntent=new Intent(this,CheckOutActivity.class);
        sendIntent.putExtra("total",totalPrice);
        sendIntent.putStringArrayListExtra("cartList",inCart);
        startActivity(sendIntent);
    }


}
