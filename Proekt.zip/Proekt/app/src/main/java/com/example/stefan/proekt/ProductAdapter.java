package com.example.stefan.proekt;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Stefan on 13.1.2018.
 */

public class ProductAdapter extends RecyclerView.Adapter<ProductInfo>{


    private Context mContext;


    private List<Product> data=new ArrayList<>();
    private LayoutInflater layoutInflater;
    private Context context;

    public ProductAdapter(Context context){
        this.context=context;
        this.layoutInflater=(LayoutInflater) context.getSystemService(Activity.LAYOUT_INFLATER_SERVICE);
    }
    @Override
    public ProductInfo onCreateViewHolder(ViewGroup parent, int viewType) {
        View rootView=layoutInflater.inflate(R.layout.product_info,null);
        ProductInfo holder=new ProductInfo(rootView);
        holder.icon=(ImageView)rootView.findViewById(R.id.product_icon);
        holder.title=(TextView) rootView.findViewById(R.id.product_title);
        holder.price=(TextView) rootView.findViewById(R.id.product_price);
        holder.button=(Button) rootView.findViewById(R.id.product_button);
        rootView.setTag(holder);
        return holder;

    }



    @Override
    public void onBindViewHolder(ProductInfo holder, int position) {
        final Product product;
        product = data.get(position);

        holder.title.setText(product.title);
        String p=Integer.toString(product.price);
        holder.price.setText(p);


        //So ova stavi gi slikickite za proizvodite
        Picasso.with(context)
                .load("http://img.omdbapi.com/?i=tt3896198&apikey=2568e8a5")
                .resize(100, 100)
                .centerCrop()
                .into(holder.icon);

        holder.icon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in = new Intent("BROADCAST_RANDOM_NUMBER");
                in.putExtra("title",product.title);
                in.putExtra("price",product.price);

                LocalBroadcastManager.getInstance(mContext).sendBroadcast(in);
            }
        });

        holder.button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in = new Intent("BROADCAST_RANDOM_NUMBER");
                in.putExtra("title",product.title);
                in.putExtra("price",product.price);

                LocalBroadcastManager.getInstance(mContext).sendBroadcast(in);
            }
        });



    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    public void setData(List<Product> data){
        this.data=data;
    }


}